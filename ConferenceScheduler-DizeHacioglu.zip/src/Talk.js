/*
Talk class - to keep track of the title and duration of each Talk.
*/

var Talk = function(title, duration){
  this.title = title;
  this.duration = duration;
}

module.exports = Talk;
